# Report: Predict Bike Sharing Demand with AutoGluon Solution
#### NAME HERE

## Initial Training
### What did you realize when you tried to submit your predictions? What changes were needed to the output of the predictor to submit your results?
Five experiments were conducted as follows:

Initial Raw Submission [Model: initial]
Added Features Submission (EDA + Feature Engineering) [Model: add_features]
Hyperparameter Optimization (HPO) - Initial Setting Submission
Hyperparameter Optimization (HPO) - Setting 1 Submission

Observation: Some experiments resulted in predictions with negative values.
Changes: Negative prediction values were replaced with 0 before submission since Kaggle rejects submissions containing negative predictions.

### What was the top ranked model that performed?
The top-ranked model was the Add Features model, named WeightedEnsemble_L3, with a validation RMSE score of 0.61715 and a Kaggle score of 0.44798 on the test dataset. Although hyperparameter-optimized models (HPO) improved RMSE scores on validation data, the Add Features model delivered the best performance on unseen test data due to the robust feature engineering process.

## Exploratory data analysis and feature creation
### What did the exploratory analysis find and how did you add additional features?
Datetime Parsing: Extracted hour, day, and month from the datetime feature.
Categorical Variables: Converted season and weather from integer to categorical types.
Feature Engineering:
Dropped features like casual, registered, and atemp due to redundancy or absence in the test dataset.
Added a new categorical feature, day_type, to capture weekday, weekend, and holiday information.
Visualizations and Insights:

Features like hour, season, and weather had a strong relationship with demand.
Dropping redundant features like atemp reduced multicollinearity and improved predictions.

### How much better did your model preform after adding additional features and why do you think that is?
Adding features led to a 66% improvement in performance compared to the initial model. The enhancement was primarily due to:

Converting categorical features to the correct type.
Incorporating time-based features, which helped capture seasonal and hourly patterns in bike demand.

## Hyper parameter tuning
### How much better did your model preform after trying different hyper parameters?
Hyperparameter tuning further improved the Kaggle score from 0.61715 to 0.48536, a 21% enhancement. Specific adjustments included:

Optimizing num_boost_round for GBM models.
Experimenting with lightweight presets like "optimize_for_deployment" to reduce computational overhead.
Observations:

AutoGluon’s performance depends heavily on time limits and preset options.
While HPO improved results, it required careful management of computational resources.

### If you were given more time with this dataset, where do you think you would spend more time?
With additional time, I would:

Experimenting with additional external datasets, such as real-time weather data.
Running hyperparameter optimization with high-quality presets for extended durations.
Exploring deep learning models like LSTMs for temporal pattern detection.
### Create a table with the models you ran, the hyperparameters modified, and the kaggle score.

	model	hpo1	hpo2	hpo3	score
0	initial	default_vals	default_vals	default_vals	1.80522
1	add_features	default_vals	default_vals	default_vals	0.61715
2	hpo	Tree-Based Models	KNN	GBM: num_boost_round: 100	0.48536
### Create a line plot showing the top model score for the three (or more) training runs during the project.

TODO: Replace the image below with your own.

![model_train_score.png](img/model_train_score.png)

### Create a line plot showing the top kaggle score for the three (or more) prediction submissions during the project.

TODO: Replace the image below with your own.

![model_test_score.png](img/model_test_score.png)

## Summary

In this project, I utilized AutoGluon to predict bike-sharing demand. The process included:

Initial Results: AutoGluon provided a baseline with minimal effort.
Feature Engineering: Significant improvements were observed after conducting exploratory data analysis and adding meaningful features.
Hyperparameter Tuning: While tuning hyperparameters enhanced performance, the computational cost and complexity were notable challenges.
Final Outcome: The model combining EDA and feature engineering without HPO achieved the best Kaggle score due to its balanced approach to data preprocessing and model training.

In this overall project, I gained lot of knowledge through implementation by solving errors.